export const publicPath = '/';

export const routeCodes = {
  HOMEPAGE: publicPath,
  CATALOGO: `${ publicPath }product`,
  REGISTRO_PRODUCTOS: `${ publicPath }add-Product`,
};