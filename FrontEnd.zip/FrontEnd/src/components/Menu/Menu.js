import React, { Component } from 'react';
import {Route,NavLink,HashRouter} from "react-router-dom";
import { routeCodes } from './../../application/routesConfig';

class Menu extends Component {

    render() {
      return (
        <div>
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
							<span class="navbar-toggler-icon"></span>
						</button>
            <div class="collapse navbar-collapse" id="navbarText">
							<ul class="navbar-nav mr-auto">
								<li class="nav-item active">
									<NavLink className={"nav-link"} to={routeCodes.HOMEPAGE}>Home <span class="sr-only">(current)</span></NavLink>
                </li>
                <li class="nav-item">
								<NavLink className={"nav-link"} to={routeCodes.CATALOGO}>Our Product</NavLink>
                </li>
                <li class="nav-item">
									<NavLink className={"nav-link"} to={routeCodes.REGISTRO_PRODUCTOS}>Register Product</NavLink>
                </li>
              </ul>
            </div>
          </nav>
				</div>
      );
    }
	}
	
	export default Menu;