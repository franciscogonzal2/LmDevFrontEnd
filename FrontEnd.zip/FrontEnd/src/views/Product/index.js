import React, { Component } from "react";
 
class Product extends Component {
  render() {
    return (
      <div>
          <div className="container">
        <div class="card card-primary">
          <div class="card-header">
            <h2>REGISTER PRODUCT</h2>
          </div>
          <div class="card-body">
           <input  class="form-control form-control-lg" type="text" placeholder="Product Name"></input>
           <p> </p>
           <input  class="form-control form-control-lg" type="text" placeholder="Category" margin = "2px"></input>
           <p> </p>
           <input  class="form-control form-control-lg" type="text" placeholder="Price" margin = "2px"></input>
           <p> </p>
           <input  class="form-control form-control-lg" type="text" placeholder="Discount" margin = "2px"></input>
          </div>
        </div>
      </div>
      </div>
    );
  }
}
 
export default Product;