import React, { Component } from "react";
 
class ourProduct extends Component {
  render() {
    return (
      <div>
          
      </div>
    );
  }
}
export default ourProduct;