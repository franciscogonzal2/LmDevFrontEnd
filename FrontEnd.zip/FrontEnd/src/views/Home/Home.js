import React, { Component } from "react";

class Home extends Component {
  render() {

    return (
      <div className="container">
        <div class="card card-primary">
          <div class="card-header">
            <h2>MARKET PLACE</h2>
          </div>
          <div class="card-body">
            <p className="card-body">nuestros productos</p>
            <lu>
              <li>
                <p ></p>
              </li>
            </lu>
          </div>
        </div>
      </div>
    );
  }
}
 
export default Home;